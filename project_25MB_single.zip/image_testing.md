## Image Integration Testing Rules
- Always use base64-encoded JPEG/PNG/WEBP only
- Images must contain real visual features (not blank/solid)
- Transcode non-standard formats to PNG/JPEG before upload
- Extract first frame of animated inputs
- Resize oversized payloads
- Re-detect MIME after transformations
