# MediMate Test Credentials

Authentication is via Emergent-managed Google OAuth (no password-based login).

## Pre-seeded test session (bypasses Google OAuth for backend testing)
Use this `session_token` in the `Authorization: Bearer <token>` header OR as `session_token` cookie:

- **user_id**: `test-user-medimate`
- **email**: `test.medimate@example.com`
- **name**: `Test MediMate`
- **session_token**: `test_session_medimate_1`

Session is valid for 7 days from last seed. Re-seed with:
```
mongosh test_database --eval "db.user_sessions.updateOne({session_token:'test_session_medimate_1'},{\$set:{expires_at:new Date(Date.now()+7*24*60*60*1000).toISOString()}})"
```

## Live Google login
Click "Continue with Google" on the landing page — only real Google-authenticated accounts work for the full UI flow.
