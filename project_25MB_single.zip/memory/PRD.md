# MediMate - PRD

## Problem Statement
Build a medical/pharmacy app inspired by https://med-check-5.preview.emergentagent.com/ with Google login plus three must-have features: Rx Label Translator (photo → translation + usage), Side Effect Check, and AI Drug Database for generic medicines (pros/cons/when to use).

## User Choices
- AI model: **Gemini 3 Flash** (`gemini-3-flash-preview`) via emergentintegrations + EMERGENT_LLM_KEY
- Auth: **Emergent-managed Google Auth**
- Languages supported: **English, Hindi, Bengali**
- Drug DB: AI-on-demand + 30 preloaded generics
- Palette: warm cream + sage/forest green + terracotta accent, light UI

## Architecture
- FastAPI backend (`/app/backend/server.py`) with `/api` prefix
- MongoDB collections: users, user_sessions, reminders, drug_cache
- React 19 frontend using Shadcn UI + Outfit/IBM Plex Sans typography

## Core routes
- `/` Landing with Google login
- `/dashboard` command center bento
- `/rx-translate` Rx Label Translator
- `/side-effects` Side Effect / Interaction checker
- `/drugs` AI Drug Database
- `/symptoms` Symptom checker
- `/pill-id` Pill identifier
- `/reminders` Dose reminders CRUD

## API endpoints
- POST `/api/auth/google/session`, GET `/api/auth/me`, POST `/api/auth/logout`
- GET `/api/drugs/preloaded`, POST `/api/drugs/search`
- POST `/api/sideeffects/check`
- POST `/api/rx/translate`, POST `/api/pill/identify`, POST `/api/symptoms/check`
- GET/POST/PATCH/DELETE `/api/reminders`

## What's implemented (Feb 2026)
- Full Google login flow (Emergent Auth) with session cookies
- All 7 feature pages wired to Gemini 3 Flash via emergentintegrations
- 30 preloaded generics + AI search with Mongo cache
- Dose reminders CRUD
- Light clean teal + cream + terracotta design system

## Backlog (P1)
- Add medication tracker history (adherence %)
- Push/browser notifications for reminders
- Multi-language expansion (Tamil, Telugu, Spanish)
- Shareable Rx translation card (PDF/image export)
