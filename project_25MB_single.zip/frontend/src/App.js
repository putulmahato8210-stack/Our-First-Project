import "@/App.css";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { AuthProvider } from "@/context/AuthContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import Landing from "@/pages/Landing";
import Dashboard from "@/pages/Dashboard";
import RxTranslator from "@/pages/RxTranslator";
import SideEffects from "@/pages/SideEffects";
import Drugs from "@/pages/Drugs";
import Symptoms from "@/pages/Symptoms";
import PillId from "@/pages/PillId";
import Reminders from "@/pages/Reminders";
import AuthCallback from "@/pages/AuthCallback";
import { Toaster } from "@/components/ui/sonner";

function AppRouter() {
  const location = useLocation();
  if (location.hash?.includes("session_id=")) {
    return <AuthCallback />;
  }
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/rx-translate" element={<ProtectedRoute><RxTranslator /></ProtectedRoute>} />
      <Route path="/side-effects" element={<ProtectedRoute><SideEffects /></ProtectedRoute>} />
      <Route path="/drugs" element={<ProtectedRoute><Drugs /></ProtectedRoute>} />
      <Route path="/symptoms" element={<ProtectedRoute><Symptoms /></ProtectedRoute>} />
      <Route path="/pill-id" element={<ProtectedRoute><PillId /></ProtectedRoute>} />
      <Route path="/reminders" element={<ProtectedRoute><Reminders /></ProtectedRoute>} />
    </Routes>
  );
}

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <AuthProvider>
          <AppRouter />
          <Toaster richColors position="top-right" />
        </AuthProvider>
      </BrowserRouter>
    </div>
  );
}

export default App;
